# SecSkills — Network & Security Learning Platform

An open-source, self-hosted security skills platform with three hands-on learning tracks.

## Tracks

| Track | Level | Lessons |
|---|---|---|
| Network Monitoring | Beginner | 14 lessons |
| Firewall Configuration | Intermediate | 13 lessons |
| Threat Detection | Advanced | 14 lessons |

## Deploy to GitHub Pages (free, live in 2 minutes)

### Step 1 — Create a GitHub repository

1. Go to [github.com](https://github.com) and sign in
2. Click **New repository** (top right, green button)
3. Name it `secskills` (or anything you like)
4. Set it to **Public**
5. Click **Create repository**

### Step 2 — Upload the files

**Option A — Drag and drop (easiest):**
1. On your new repo page, click **uploading an existing file**
2. Drag the entire `security-skills` folder contents into the upload area
3. Scroll down, click **Commit changes**

**Option B — Git CLI:**
```bash
cd security-skills
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/secskills.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages

1. Go to your repo → **Settings** → **Pages** (left sidebar)
2. Under **Source**, select **Deploy from a branch**
3. Branch: `main` / Folder: `/ (root)`
4. Click **Save**

### Step 4 — Visit your live site

After 1–2 minutes, your site is live at:
```
https://YOUR_USERNAME.github.io/secskills/
```

That's it. Share the URL with anyone.

---

## File structure

```
security-skills/
├── index.html              ← Homepage
├── css/
│   └── style.css           ← All styles
├── js/
│   └── main.js             ← Canvas animation + quiz logic
└── pages/
    ├── tracks.html         ← All tracks overview
    └── lessons/
        ├── network-01.html ← Network monitoring lessons
        ├── network-02.html
        ├── network-03.html
        ├── firewall-01.html← Firewall lessons
        └── threat-01.html  ← Threat detection lessons
```

## Adding more lessons

Copy an existing lesson file (e.g. `network-03.html`) and:
1. Update the `<title>` tag
2. Update the lesson number in the header (`LESSON 04 OF 14`)
3. Update the active sidebar link
4. Write your content inside `.lesson-body`
5. Update the quiz at the bottom (change the correct answer index in `initQuiz('quiz-id', INDEX)`)
6. Update the nav buttons at the bottom

## License

MIT — free to use, modify, and redistribute.
